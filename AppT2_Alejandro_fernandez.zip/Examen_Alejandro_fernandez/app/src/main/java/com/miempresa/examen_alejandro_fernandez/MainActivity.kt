package com.miempresa.examen_alejandro_fernandez

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
               //declaramos los botones
        val btnActivity_consulta_plato = findViewById<Button>(R.id.btnConsultaPl)
        val  btnNuevoplato = findViewById<Button>(R.id.btnNuevoPl)
        val listView: ltPlatos= findViewById(R.id.ltPlatos)



        //damos uncionalidad a los botones
        btnNuevoplato.setOnClickListener {
            startActivity(Intent(this, ActivityNuevoplato::class.java))
        }
        btnActivity_consulta_plato.setOnClickListener {
            startActivity(Intent(this, Activity_consulta_plato::class.java))
        }
    }
}