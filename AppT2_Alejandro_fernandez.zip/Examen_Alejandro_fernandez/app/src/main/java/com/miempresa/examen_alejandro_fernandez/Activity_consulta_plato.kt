package com.miempresa.examen_alejandro_fernandez

import android.database.DatabaseUtils
import android.database.sqlite.SQLiteOpenHelper
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView
import java.sql.DatabaseMetaData

class Activity_consulta_plato : AppCompatActivity(){

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_consulta_plato)

        val platos_tipicos = obtenerListaDePlatos()
        val platoAdapter = PlatoAdapter(platos)

        ListView.adapter=platoAdapter
        listView.setOnItemClickListener { parent, view, position, id ->
            // Lógica para manejar el clic en un elemento de la lista
        }


    }

}