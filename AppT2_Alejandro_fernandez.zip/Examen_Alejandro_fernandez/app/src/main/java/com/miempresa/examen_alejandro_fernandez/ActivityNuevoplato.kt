package com.miempresa.examen_alejandro_fernandez

import android.content.ContentValues
import android.database.sqlite.SQLiteOpenHelper
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import java.sql.DatabaseMetaData

class ActivityNuevoplato : AppCompatActivity() {
    private  lateinit var BD_Platos: DatabaseMetaData
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_nuevoplato)
                //se invoca la BD
        DB_Platos = DatabaseMetaData(this)
                         //declara los atributos
        val  etNombre = findViewById<EditText>(R.id.txtPlato)
        val  etPrecio = findViewById<EditText>(R.id.txtPrecioPla)
        val etZona = findViewById<EditText>(R.id.txtDepar)
        val etTipo = findViewById<EditText>(R.id.txtTipoPlato)
        val etCodigo = findViewById<EditText>(R.id.txtCodigo)
        val btnGuarddar = findViewById<Button>(R.id.btnGrabarPl)

        //declara los botones
        btnGuarddar.setOnClickListener {
            val nombre_plato = etNombre.text.toString()
            val  precio_plato = etPrecio.text.toString().toDoubleOrNull()
            val  codigo_plato = etCodigo.text.toString()
            val  Tipo_plato = etTipo.text.toString()
            val  zona_plato = etZona.text.toString()

            if(nombre_plato.isNotBlank() && precio_plato != null && zona_plato.isNotBlank()){
                val  db = DB_Platos.writeTableDatabase
                val  values = ContentValues().apply {
                    put(BD_Platos.Nombre_Plato , nombre_plato)
                    put(BD_Platos.Precio_Plato  , precio_plato)
                    put(BD_Platos.Zona , zona_plato)
                }
                val newRowId = db.insert(DatabaseMetaData.platos_tipicos, null, values)
                if (newRowId != -1L){
                    Toast.makeText(this, "El platos e guardo correctamente",Toast.LENGTH_SHORT).show()
                    etNombre.text.clear()
                    etCodigo.text.clear()
                    etPrecio.text.clear()
                    etTipo.text.clear()
                    etZona.text.clear()
                }else{
                    Toast.makeText(this,"Error nos e gurdo el plato revise.", Toast.LENGTH_SHORT).show()
                }
            }else{
                Toast.makeText(this, "Por favor llene todas las casillas :D", Toast.LENGTH_SHORT).show()
            }
        }

    }
}