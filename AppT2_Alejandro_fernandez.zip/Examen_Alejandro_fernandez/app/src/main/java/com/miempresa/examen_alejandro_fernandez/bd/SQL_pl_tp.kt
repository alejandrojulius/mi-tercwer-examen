package com.miempresa.examen_alejandro_fernandez.bd

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class SQL_pl_tp(context: Context): SQLiteOpenHelper(context, BD_Platos, null, DATABASE_1 ) {
    override fun onCreate(db: SQLiteDatabase) {
                //aqui nace la BD
        val createTableQuery = "Create Table $tabla_plato"+"($Cod_Plato interger primary key Autoincrement,"+"$Nombre_Plato text"+"$Precio_Plato REAL"+"$Zona TEXT"+"$Tipo_Plato TEXT)"
        db.execSQL(createTableQuery)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        //soporte de modificacioens
    }
    companion object{
        private const val  BD_Platos = "Platos_DBBA"
        private  const val  DATABASE_1 = 1
        const val tabla_plato = "platos tipicos"
        const val  Cod_Plato = "id"
        const val  Nombre_Plato = "nombre_plato"
        const val  Precio_Plato = "el_precio"
        const val  Zona = "zona_plato"
        const val  Tipo_Plato = "tipo_plato_rico"

    }

}